 var usersPayload = context.getVariable("calloutResponseUsers.content");
 var postsPayload = context.getVariable("calloutResponsePost.content");
 usersPayload = JSON.parse(usersPayload);
 postsPayload = JSON.parse(postsPayload);
 var arrayResponse = [];
 var i;
print(postsPayload.length);
 for(i=0; i<usersPayload.length; i++)
 {  
     for(var j=0; j<postsPayload.length;j++){
         if(usersPayload[i].id == postsPayload[j].id)
         {
             var output = {
                            "id": usersPayload[i].id,
                            "Company": usersPayload[i].company,
                            "Latitute": usersPayload[i].address.geo.lat,
                            "Longitude": usersPayload[i].address.geo.lng,
                            "Title": postsPayload[j].title,
                            "Body": postsPayload[j].body
                            };
         }
     }
     arrayResponse.push(output);
 }
 
context.setVariable("arrayResponse",JSON.stringify(arrayResponse));